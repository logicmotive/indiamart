## Indiamart Integration

Indiamart Integration

This integration pull data from indiamart and create lead in erpnext.

Every 20minute cron job run and pull data from india mart and create lead. If you want to stop cron job then just comment code from hook file.

We added manually pull data option in 'Indiamart Setting' Page.


Setup step:
1. get your key from indiamart portal and set into indiamart setting page.
2. mobile number should be that which is registered with indiamart.
3. email id registered at indiamart.


#### License

MIT
